import sys
import json
import datetime
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC



base_url = "https://www.sfpproperty.com/property-search/"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(8)

property_urls = []
while(is_element_exists(driver, By.CSS_SELECTOR, ".page-numbers")):
    property_links = driver.find_elements(
        By.CSS_SELECTOR, ".es-thumbnail a")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))
            
    if not is_element_exists(driver, By.CSS_SELECTOR, ".next"):
        property_links = driver.find_elements(By.CSS_SELECTOR, ".es-thumbnail a")

        for span in property_links:
            if span.get_attribute("href") not in property_urls:
                property_urls.append(span.get_attribute("href"))
        break

    driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, ".next"))))

for link in property_urls:

    try:
        print("Link: ", link)
        driver.get(link)

        name = type_property = address = brochure = points = paragraph = rent_unit = ""
        rent = property_value = latitude = longitude = 0
        agent_details = {}
        image_urls = []
        description = []
        
        # Name and Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".es-address"):
            name = driver.find_element(By.CSS_SELECTOR, ".es-address").text
            address = driver.find_element(By.CSS_SELECTOR, ".es-address").text
        
        # Features of Property
        features = []
        if is_element_exists(driver, By.CSS_SELECTOR, ".es-property-fields ul li"):
            features = driver.find_elements( By.CSS_SELECTOR, ".es-property-fields ul li")
            features = [i.text for i in features]
            
            for feature in features:
                if feature.startswith("Price"):
                    rent = float(feature.split("£")[1].replace(",",""))
                if feature.startswith("Method"):
                    rent_unit = feature.split(':')[1]
                if feature.startswith("Type"):
                    type_of_property = feature.split(":")[1]
          
        # Brochure Link of Property          
        if is_element_exists(driver, By.CSS_SELECTOR, ".es-file__content a"):
            brochure = driver.find_element(By.CSS_SELECTOR, ".es-file__content a").get_attribute("href")
        
        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".es-description p"):
            paragraph = driver.find_element(By.CSS_SELECTOR, ".es-description p").text
            
        if is_element_exists(driver, By.CSS_SELECTOR, ".es-description li"):
            points = driver.find_elements(By.CSS_SELECTOR, ".es-description li")
            points = [i.text for i in points]

        description.append({"type": "text", "value": paragraph})
        description.append({"type": "list", "value": points})
    
        # Agent-Details
        if is_element_exists(driver, By.CSS_SELECTOR, ".single-properties #sidebar .request_property_cta p a"):
            agent_details["Number"] = driver.find_element(
                By.CSS_SELECTOR, ".single-properties #sidebar .request_property_cta p a").text.split(":")[1]

        # Images of Property
        if is_element_exists(driver,By.CSS_SELECTOR, ".slick-slide img" ):
            image_urls = driver.find_elements(By.CSS_SELECTOR, ".slick-slide img")
            image_urls = [i.get_attribute('src') for i in image_urls]
        
        
        payload = []
        payload.append(link)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append("FOR RENT")
        payload.append(0)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print(type(e).__name__, __file__, e, e.__traceback__.tb_lineno)
        f = open("error.log", "a")
        f.write(f"Filename: {sys.argv[0]} \n")
        f.write(f"Error in link: {link} \n")
        f.write(f"Time:- {datetime.datetime.now()} \n")
        f.write(str(traceback.format_exc()))
        f.write("\n")
        f.close()
        pass


driver.close()