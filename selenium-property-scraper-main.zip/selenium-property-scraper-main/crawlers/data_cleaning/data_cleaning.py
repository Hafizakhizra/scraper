import psycopg2
import numpy as np
import psycopg2.extras as extras
import pandas as pd

# Reading CSV FIle
codes = pd.read_csv('postcodes.csv')

# Executing Values to store in SQL
def execute_values(conn, df, table):

    tuples = [tuple(x) for x in df.to_numpy()]

    cols = ','.join(list(df.columns))
    # SQL query to execute
    query = "INSERT INTO %s(%s) VALUES %%s" % (table, cols)
    cursor = conn.cursor()
    try:
        extras.execute_values(cursor, query, tuples)
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print("Error: %s" % error)
        conn.rollback()
        cursor.close()
        return 1
    print("the dataframe is inserted")
    cursor.close()

# Database Connection 
conn = psycopg2.connect(database="property_pool",
                        user='postgres', 
                        password='1234', 
                        host='localhost',
                        port='5432')
execute_values(conn, codes, 'geo_country')

# Transforming into Key: Value Pair
p_codes= {}
for i in range(len(codes['postcode'])):
    p_codes[codes['postcode'][i]] = codes['town'][i]
    

# Reading Data from Properties
sql_query = """
    SELECT * 
    FROM Properties
"""
df = pd.read_sql_query(sql_query,conn)


query = """
    ALTER TABLE properties 
        ADD COLUMN geo_country_id VARCHAR(10) 
        REFERENCES geo_country (postcode);
        """


# Checking for post_code in address and description 
for address in df['address']:
    for description in df['description']:
        for code in p_codes.keys():
            if code in address:
                query = f"""update properties
                            set geo_country_id = {code}
                            where address = {address}
                            """
                try:
                    conn.cursor.execute(query)
                    conn.commit()
                    
                except (Exception, psycopg2.DatabaseError) as error:
                    print("Error: %s" % error)
                    conn.rollback()
                    conn.cursor.close()