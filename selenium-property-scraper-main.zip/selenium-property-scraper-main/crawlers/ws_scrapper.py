import sys
import json
import datetime
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.relative_locator import locate_with


base_urls = ["https://www.walkersingleton.co.uk/residential-sales/?type=sales&location=&propMinPrice=&propMaxPrice=&propBeds=",
             "https://www.walkersingleton.co.uk/residential-lettings/?type=lettings&location=&propMinPrice=&propMaxPrice=&propBeds=",
             "https://www.walkersingleton.co.uk/commercial-industrial-property/?type=sales&location=&propType=&propSize=",
             "https://www.walkersingleton.co.uk/commercial-industrial-property/?type=lettings&location=&propType=&propSize="]

driver = get_chrome_driver()
connection = create_server_connection()
cursor = connection.cursor()

property_urls = []
for url in base_urls:
    driver.get(url)
    print("Base Url: ", url)

    pages_list = []
    while(driver.find_element(locate_with(By.CSS_SELECTOR, ".paging li"))):

        property_links = driver.find_elements(
            By.CSS_SELECTOR, ".block .button.bg-blue.white")
        for span in property_links:
            if span.get_attribute("href") not in property_urls:
                property_urls.append(span.get_attribute("href"))

        active_page = driver.find_element(By.CSS_SELECTOR, ".paging li.active")
        next_page = driver.find_element(locate_with(
            By.CSS_SELECTOR, ".paging li a").near(active_page)).get_attribute("href")

        if next_page not in pages_list:
            pages_list.append(next_page)

            driver.get(next_page)

            property_links = driver.find_elements(
                By.CSS_SELECTOR, ".block .button.bg-blue.white")
            for span in property_links:
                if span.get_attribute("href") not in property_urls:
                    property_urls.append(span.get_attribute("href"))
        else:
            break

for url in property_urls[100:]:
    try:
        print("Link: ", url)
        driver.get(url)
        driver.implicitly_wait(8)

        name = type_of_property = address = brochure = rent_unit = type_property = ""
        rent = property_value = latitude = longitude = 0
        description = ""
        agent_details = {}
        image_urls = []

        # Name and Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".title p"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".title p").text.split(",")[0].replace("'","")
            address = driver.find_element(By.CSS_SELECTOR, ".title p").text.replace("'","")

        # Type of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".title-top p"):
            type_of_property = driver.find_element(
                By.CSS_SELECTOR, ".title-top p").text.split("\n")[0]

        # Brochure of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "a.bg-grey.button"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, "a.bg-grey.button").get_attribute('href')

        # Agent Details of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".viewing .contact-name"):
            agent_details["agent_name"] = driver.find_element(
                By.CSS_SELECTOR, ".viewing .contact-name").text
        if is_element_exists(driver, By.CSS_SELECTOR, ".viewing .direct-num"):
            agent_details["agent_phone"] = driver.find_element(
                By.CSS_SELECTOR, ".viewing .direct-num").text
        if is_element_exists(driver, By.CSS_SELECTOR, ".viewing .contact-info a"):
            agent_details["agent_email"] = driver.find_element(
                By.CSS_SELECTOR, ".viewing .contact-info a").text

        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-inner .gallery .thumbs img"):
            image_urls = driver.find_elements(
                By.CSS_SELECTOR, ".property-inner .gallery .thumbs img")
            image_urls = list(set([i.get_attribute("src") for i in image_urls]))

        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".information .main"):
            description = driver.find_elements(
                By.CSS_SELECTOR, ".information .main")
            description = [i.text.replace("'", "")
                        for i in description][0].split("\n")
            description = [i for i in description if len(i) > 0]

        # Property Features
        if is_element_exists(driver, By.CSS_SELECTOR, '.price-container span'):
            if driver.find_element(By.CSS_SELECTOR, '.price-container span').text.lower() == "for sale":
                if is_element_exists(driver, By.CSS_SELECTOR, ".price"):
                    value = driver.find_element(
                        By.CSS_SELECTOR, ".price").text.split(' ')
                    for val in value:
                        if val.startswith('£'):
                            property_value = float(val[1:].replace(",", ""))
                            
        if is_element_exists(driver, By.CSS_SELECTOR, '.price-container span'):
            if driver.find_element(By.CSS_SELECTOR, '.price-container span').text.lower() == "to let":
                if is_element_exists(driver, By.CSS_SELECTOR, ".price"):
                    value = driver.find_element(By.CSS_SELECTOR, ".price").text
                    value = [i.lower() for i in value.split(" ")]

                    if "pcm" in value:
                        rent_unit = "PCM"
                        rent = float([i[1:].replace(",", "")
                                     for i in value if i.startswith("£")][0])
                    if "sqft" in value:
                        rent_unit = "Per Sq Ft"
                        rent = [i[1:].replace(",", "")for i in value if i.startswith("£")][0]
                        if rent.endswith('/'):
                            rent = float(rent[:-1])
                        
                    else:
                        for val in value:
                            if val.startswith('£'):
                                rent = float(val[1:].replace(",",""))

        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass

driver.close()
