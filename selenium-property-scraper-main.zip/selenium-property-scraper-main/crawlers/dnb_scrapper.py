import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://www.daltonsbusiness.com/hotels-businesses-for-sale"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)


# Property Urls extraction from every page
property_urls = []
while(driver.find_element(By.CSS_SELECTOR, '[aria-label="Next"]')):

    property_links = driver.find_elements(By.CSS_SELECTOR, ".listing-v1 .list-view .item-body .item-title a")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))

    driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, '[aria-label="Next"]'))))
    
    
for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        description = []
        image_urls = []
        agent_details = ""
        
        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".page-title h1 "):
            name =  driver.find_elements(By.CSS_SELECTOR, ".page-title h1")
            name = [i.text for i in name if len(i.text)>0][0].replace("'","")
        
        # Type of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.labels-wrap a'):
            type_of_property = driver.find_element(By.CSS_SELECTOR, '.labels-wrap a').text
            
        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.item-address a'):
            address = driver.find_elements(By.CSS_SELECTOR, '.item-address a')
            address = " ".join([i.text for i in address]).strip().replace("'","")
            
        # Property Value of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.leashold-price'):
            property_value = float(driver.find_elements(By.CSS_SELECTOR, '.leashold-price')[1].text.split("£")[1].replace(",",""))
        elif is_element_exists(driver, By.CSS_SELECTOR, '.item-price'):
            property_value = float(driver.find_elements(By.CSS_SELECTOR, '.item-price')[1].text.split("£")[1].replace(",",""))
        elif is_element_exists(driver, By.CSS_SELECTOR, '.freehold-price'):
            property_value = float(driver.find_elements(By.CSS_SELECTOR, '.freehold-price')[1].text.split("£")[1].replace(",",""))
          
        # Description of Propert  
        if is_element_exists(driver, By.CSS_SELECTOR, '.block-content-wrap p'):
            description = driver.find_elements(By.CSS_SELECTOR, '.block-content-wrap p')
            description = " ".join([i.text for i in description]).strip().replace("\n"," ").replace("'","")
            
        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR,'.top-gallery-section img'):
            image_urls = driver.find_elements(By.CSS_SELECTOR,'.top-gallery-section img')
            image_urls = [i.get_attribute('src') for i in image_urls if i.get_attribute('src') is not None]
        
        
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass
    
driver.close()
