import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://www.matthews-goodman.co.uk/property-search/"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(8)

property_urls = []
for span in driver.find_elements(By.CSS_SELECTOR, '.article-properties h3 a'):
    property_urls.append(span.get_attribute("href"))


for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = description = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        image_urls = []

        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-detail h1:nth-of-type(2)"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".property-detail h1:nth-of-type(2)").text.replace("'", "")

        # Address and Description
        if is_element_exists(driver, By.CSS_SELECTOR, '.property-detail h2'):
            info_of_property = driver.find_elements(
                By.CSS_SELECTOR, '.property-detail h2')
            info_of_property = [i.text for i in info_of_property]

            if "Location:" in info_of_property:
                address = driver.find_element(
                    By.CSS_SELECTOR, ".property-detail p:nth-of-type(1)").text.replace("'", "")

            if "Description:" in info_of_property:
                description = driver.find_element(
                    By.CSS_SELECTOR, ".property-detail p:nth-of-type(2)").text.replace("'", "")

        # Agent Details of Property
        agent_details = {}
        if is_element_exists(driver, By.CSS_SELECTOR, '.contact-info .name-title a'):
            agent_names_elements = driver.find_elements(
                By.CSS_SELECTOR, '.contact-info .name-title a')
            agent_names = [i.text.split('\n')[1] for i in agent_names_elements]

        if is_element_exists(driver, By.CSS_SELECTOR, ".contact-info .link-holder a"):
            agent_phones_elements = driver.find_elements(
                By.CSS_SELECTOR, ".contact-info .link-holder a")
            agent_phones = [i.text for i in agent_phones_elements]

        if is_element_exists(driver, By.CSS_SELECTOR, ".contact-info img"):
            agent_images_elements = driver.find_elements(
                By.CSS_SELECTOR, ".contact-info img")
            agent_images = [i.get_attribute('src')
                            for i in agent_images_elements]

        agent_details = {}
        a_count = 0
        for i in agent_names:
            agent_details[f"agent_no_{a_count+1}"] = [agent_names[a_count],
                                                      agent_phones[a_count], agent_images[a_count]]
            a_count += 1

        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".image img"):
            image_urls_list = driver.find_elements(
                By.CSS_SELECTOR, ".image img")
            image_urls = []
            for image in image_urls_list:
                if image.get_attribute("src") not in image_urls_list:
                    image_urls.append(image.get_attribute("src"))

        # Features of Propertty
        features = {}
        if is_element_exists(driver, By.CSS_SELECTOR, ".dl-horizontal dt"):
            features_keys = driver.find_elements(
                By.CSS_SELECTOR, ".dl-horizontal dt")
            features_keys = [i.text for i in features_keys[1:]]
        if is_element_exists(driver, By.CSS_SELECTOR, ".dl-horizontal dd"):
            features_values = driver.find_elements(
                By.CSS_SELECTOR, ".dl-horizontal dd")
            features_values = [i.text for i in features_values]
            
        if len(features_keys)!= len(features_values):
            features_keys = features_keys[1:]
        else:
            features = dict(zip(features_keys, features_values))
            if "Rent:" in features:
                value = features["Rent:"].split(" ")
                if "sq" and "ft" in value:
                    rent_unit = "Per sq ft"
                    rent = float([i.replace(",", "")
                                for i in value if i.startswith("£")][0][1:])
                if "pcm" in value:
                    rent_unit = "PCM"
                    rent = float([i.replace(",", "")
                                for i in value if i.startswith("£")][0][1:])
                if "per" and "annum" in value:
                    rent_unit = "Per Annum"
                    rent = float([i.replace(",", "")
                                for i in value if i.startswith("£")][0][1:])
                if "pa" in value:
                    rent_unit = "PA"
                    rent = float([i.replace(",", "")
                                for i in value if i.startswith("£")][0][1:])
                if "per" and "month" in value:
                    rent_unit = "Per Month"
                    rent = float([i.replace(",", "")
                                for i in value if i.startswith("£")][0][1:])
            if "Property type:" in features:
                type_of_property = features["Property type:"].replace("'","")
                type_property = features["Property type:"].replace("'","")
            if "Price:" in features:
                property_value = features["Price:"].split(" ")
                for val in property_value:
                    if val.startswith('£'):
                        property_value = val[1:].replace(",","")
                    else:
                        property_value = 0

        # Brochure of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".contact-holder.text-center:nth-of-type(3) .particulars-downloads a"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, ".contact-holder.text-center:nth-of-type(3) .particulars-downloads a").get_attribute('href')


        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(0)
        payload.append(0)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass
    
driver.close()