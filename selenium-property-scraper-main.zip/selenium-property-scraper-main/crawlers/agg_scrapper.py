import sys
import json
import datetime
import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.driver_config import get_chrome_driver
from helper.element_exist import is_element_exists
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://agg.uk.com/properties/grid?keywords=&price=All&type=All&tenure=All&sort_bef_combine=created_1_DESC&sort_by=created_1&sort_order=DESC&page=0"
driver = get_chrome_driver()
driver.get(base_url)

connection = create_server_connection()
cursor = connection.cursor()

property_urls = []
while(is_element_exists(driver, By.CSS_SELECTOR, ".next a")):
    property_links = driver.find_elements(
        By.CSS_SELECTOR, ".field-content a")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))

    driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, ".next a"))))



for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url+"#main-content")
        driver.implicitly_wait(8)
        #if is_element_exists(driver, )

        name = type_of_property = address = brochure = rent_unit = type_property = ""
        rent = property_value = latitude = longitude = 0
        description = []
        agent_details = {}
        image_urls = []
        
        if is_element_exists(driver, By.CSS_SELECTOR, ".agg-subscribe-form"):
            email_form = driver.find_element(By.XPATH, '/html/body/div[3]/div/div/form/div[1]/input')
            phone_form = driver.find_element(By.XPATH, '/html/body/div[3]/div/div/form/div[2]/input')
            radio_form = driver.find_element(By.XPATH, "/html/body/div[3]/div/div/form/div[3]/div/label[1]/input")
            
            email_form.send_keys("abcd1234@gmail.com")
            phone_form.send_keys("09870912345")
            radio_form.click()
            
            submit = driver.find_element(By.XPATH, "/html/body/div[3]/div/div/form/div[5]/button")
            submit.click()
        
        
            
        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".title" ):
            name = driver.find_element(By.CSS_SELECTOR, ".title").text.replace("'","")
        
        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".field-address"):
            address = driver.find_element(By.CSS_SELECTOR, ".field-address").text.replace("'","")

        # Agent-Details of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".call span"):
            agent_details = driver.find_element(By.CSS_SELECTOR, ".call span").text[1:]

        # Brochure link of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".brochure "):
            brochure = driver.find_element(By.CSS_SELECTOR, ".brochure ").get_attribute('href')
            
        # Value of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.field-price'):
            value = driver.find_element(By.CSS_SELECTOR, '.field-price').text.split(' ')
            value = [i.lower() for i in value]
            rent = rent_unit= property_value =0

            if "price" in value:
                property_value = value[value.index("price")+1][1:].replace(",","")
                if len(property_value)>1:
                    property_value = float(property_value)
            if "rent" in value:
                if "pa" in value:
                    rent_unit = "Per Annum"
                    rent =  float(value[value.index("rent")+1][1:].replace(",",""))
                if "per" and "annum" in value:
                    rent_unit = "Per Annum"
                    rent =  float(value[value.index("rent")+1][1:].replace(",",""))
                if "per" and 'sq' in value:
                    rent_unit = "Per Sq Ft"
                    rent =  float(value[value.index("rent")+1][1:].replace(",",""))
                if "per" and 'month' in value:
                    rent_unit = "Per Month"
                    rent =  float(value[value.index("rent")+1][1:].replace(",",""))
                    
            else:
                for i in value:
                    if i.startswith('£'):
                        property_value = float(i[1:].replace(",",""))

            # Type of Property
            if len(str(property_value))>len(str(rent)):
                type_property = "FOR SALE"
            else:
                type_property = "FOR RENT"
            
            # Description of Property
            if is_element_exists(driver,By.CSS_SELECTOR, ".field-feature li"):
                description = driver.find_elements(By.CSS_SELECTOR, ".field-feature li")
                description =  [i.text.replace("'","") for i in description]
            
            # Images of Property
            if is_element_exists(driver, By.CSS_SELECTOR, ".img-responsive"):    
                images_urls = driver.find_elements(By.CSS_SELECTOR, ".img-responsive")
                image_urls =[i.get_attribute('src') for i in images_urls]

        
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))
        
        
        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print(type(e).__name__, __file__, e, e.__traceback__.tb_lineno)
        f = open("error.log", "a")
        f.write(f"Filename: {sys.argv[0]} \n")
        f.write(f"Error in link: {url} \n")
        f.write(f"Time:- {datetime.datetime.now()} \n")
        f.write(str(traceback.format_exc()))
        f.write("\n")
        f.close()
        pass

driver.close()

