import re
import json
import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.driver_config import get_chrome_driver
from helper.element_exist import is_element_exists
from helper.connection import create_server_connection
    
base_url = "https://www.folkesproperties.com/?post_type=property&s="
connection = create_server_connection()
cursor = connection.cursor()
driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(10)

property_urls = []
for span in driver.find_elements(By.CSS_SELECTOR, '.group.search-results a'):
    property_urls.append(span.get_attribute("href"))
    
    
for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)
        driver.implicitly_wait(8)
        
        name = type_of_property = address = brochure = rent_unit = type_property = features_list = ""
        rent = property_value = latitude = longitude = 0
        image_urls = []
        
        if is_element_exists(driver ,By.CSS_SELECTOR, '.property-page-nav h1'):
            name_address = driver.find_element(By.CSS_SELECTOR, ".property-page-nav h1")
            name = name_address.text.split('\n')[0]
            address = name_address.text.split('\n')[1]
            
            
        description = []
        if is_element_exists(driver ,By.CSS_SELECTOR, '.inner.main-content .group:nth-of-type(1) p'):
            description_elements =[i.text for i in driver.find_elements(By.CSS_SELECTOR,".inner.main-content .group:nth-of-type(1) p")]
            for value in description_elements:
                
                if value.startswith("Rental:"):
                    rent_value = value.split(" ")
                    
                    for i in rent_value:
                        rent = float(i.replace(",","")) if i.startswith("£") else 0
                    if "sq" and "ft" in rent_value:
                        rent_unit = "Per sq ft"
                    if "pcm" in value:
                        rent_unit = "PCM"
                    if "per" and "annum" in rent_value:
                        rent_unit = "Per Annum"
                
                if value.startswith("Viewing and enquiries:"):
                    agent_details = re.findall(r'[0-9]+ [0-9]+ [0-9]+', value)[0] 
                    
                if value.startswith("Rateable Value:"):
                    property_value = float([i.replace(",","") for i in value.split(" ") if i.startswith("£")][0][1:])
                
            location = [i.text for i in driver.find_elements(By.CSS_SELECTOR,".inner.main-content .group:nth-of-type(3) p") if len(i.text)>0]
            features = [i.text for i in driver.find_elements(By.CSS_SELECTOR, ".filters li") if len(i.text)>0]
            
            description.append({"type": "text", "value":  " ".join(description_elements)})
            description.append({"type": "text", "value": " ".join(location)})
            description.append({"type": "list", "value":features})
            
        if is_element_exists(driver, By.CSS_SELECTOR, ".download"):
            brochure = driver.find_element(By.CSS_SELECTOR, ".download a").get_attribute('href')
                
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))
         
        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print("Error: ",e)
        exc = traceback.format_exc()
        exception(url,exc)
        pass


driver.close()