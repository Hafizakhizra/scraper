import sys
import json
import traceback
import datetime
from selenium.webdriver.common.by import By
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


driver = get_chrome_driver()
driver.get('https://www.brutonknowles.co.uk/property-search?start=&Itemid=165')
driver.implicitly_wait(10)


connection = create_server_connection()
cursor = connection.cursor()

property_urls = []
while (driver.find_element(By.CSS_SELECTOR, ".pagination li:nth-child(13)").get_attribute('class') != 'disabled'):

    property_links = driver.find_elements(
        By.CSS_SELECTOR, ".ip-overview-title a")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))

    driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, ".pagination li:nth-child(13) a"))))


for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)
        driver.implicitly_wait(8)

        name = type_of_property = address = brochure = block_quote = paragraph = rent_unit = type_property = ""
        rent = property_value = latitude = longitude = 0
        agent_details = {}
        image_urls = []

        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".ip-sidecol address strong"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".ip-sidecol address strong").text
            name = name.replace("'", "")

        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".ip-sidecol address strong"):
            address = " ".join(driver.find_element(
                By.CSS_SELECTOR, ".ip-sidecol.ip-mainaddress address").text.split('\n'))
            address = address.replace("'", "")

        # Type_of_property (Sale, Rent and To Let)
        if is_element_exists(driver, By.CSS_SELECTOR, ".ip-sidecol.bksaletype"):
            type_of_property = driver.find_element(
                By.CSS_SELECTOR, ".ip-sidecol.bksaletype").text
            type_of_property = type_of_property.replace("'", "")

        # Property_value and Rent/Rent_unit
        if is_element_exists(driver, By.CSS_SELECTOR, ".ip-detail-price"):
            value = driver.find_element(
                By.CSS_SELECTOR, ".ip-detail-price").text

            if len(value) > 0:

                value = value.split(" ")

                if "Sq" and "Ft" in value:
                    rent_unit = "Per sq ft"
                    rent = float(
                        [i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                if "PCM" in value:
                    rent_unit = "PCM"
                    rent = float(
                        [i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                if "Per" and "Annum" in value:
                    rent_unit = "Per Annum"
                    rent = float(
                        [i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                else:
                    for val in value:
                        if val.startswith("£"):
                            property_value = float(val[1:].replace(",",""))

        # Agent Details of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".agentinfo a.agentname"):
            agent_details['agent_name'] = driver.find_element(
                By.CSS_SELECTOR, ".agentinfo a.agentname").text

        if is_element_exists(driver, By.CSS_SELECTOR, ".agentinfo span a"):
            agent_details['agent_email'] = driver.find_element(
                By.CSS_SELECTOR, ".agentinfo span a").text

        if is_element_exists(driver, By.CSS_SELECTOR, ".agentinfo .agentdetails .sidecol-agentaddress"):
            agent_details['agent_address'] = driver.find_element(
                By.CSS_SELECTOR, ".agentinfo .agentdetails .sidecol-agentaddress").text
            agent_details['agent_address'] = agent_details['agent_address'].replace(
                "'", "")

        if is_element_exists(driver, By.CSS_SELECTOR, ".agentinfo .agentdetails .sidecol-phone"):
            agent_details['agent_phone'] = driver.find_element(
                By.CSS_SELECTOR, ".agentinfo .agentdetails .sidecol-phone").text

        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, 'div.col-lg-8.col-md-8.col-sm-7.col-xs-12.pull-left.ip-desc-wrapper'):
            description = driver.find_elements(
                By.CSS_SELECTOR, 'div.col-lg-8.col-md-8.col-sm-7.col-xs-12.pull-left.ip-desc-wrapper')

            description = description[0].text[:len(
                description[0].text)-15].replace('\n', "").replace("'", "")

        # Brochure Link of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "div.col-lg-8.col-md-8.col-sm-7.col-xs-12.pull-left.ip-desc-wrapper p a"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, 'div.col-lg-8.col-md-8.col-sm-7.col-xs-12.pull-left.ip-desc-wrapper p a').get_attribute('href')

        # Property_type (Office, Land and Farms, Industrial)
        if is_element_exists(driver, By.CSS_SELECTOR, ".ip-sidecol.ip-categories span:nth-child(2)"):
            type_property = driver.find_element(
                By.CSS_SELECTOR, ".ip-sidecol.ip-categories span:nth-child(2)").text

        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.ip-galleryplug-img div a img'):
            for picture in driver.find_elements(By.CSS_SELECTOR, ".ip-galleryplug-img div a img"):
                image_urls.append(picture.get_attribute('src'))

        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(0)
        payload.append(0)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
    except Exception as e:
        print(type(e).__name__, __file__, e, e.__traceback__.tb_lineno)
        f = open("error.log", "a")
        f.write(f"Filename: {sys.argv[0]} \n")
        f.write(f"Error in link: {url} \n")
        f.write(f"Time:- {datetime.datetime.now()} \n")
        f.write(str(traceback.format_exc()))
        f.write("\n")
        f.close()
        pass


driver.close()