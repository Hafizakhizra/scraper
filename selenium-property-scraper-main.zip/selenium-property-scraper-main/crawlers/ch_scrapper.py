import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://www.clarkeholland.com/site/go/search?sales=true&min=0&includeUnavailable=true&beds=0&items=12&type=0&max=0&location=&search=&page=1&up=false&sort=onmarket"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)

property_urls =[]
while(driver.find_element(By.CSS_SELECTOR, '.pagination')):

    property_links = driver.find_elements(By.CSS_SELECTOR, ".col-sm-4.searchResultContainer a")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))
    if is_element_exists(driver, By.CSS_SELECTOR, ".pagination li:last-child"):
        if driver.find_element(By.CSS_SELECTOR, ".pagination li:last-child").text == "Next":
            next_link = driver.find_element(By.CSS_SELECTOR, ".pagination li:last-child a").get_attribute("href")
            driver.get(next_link)
        else:
            break
    else:
        break
    

for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = rent_unit = ""
        rent = property_value = latitude = longitude = 0
        description = []
        image_urls = []
        agent_details = ""
        
        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "#particularsBedrooms"):
            name = driver.find_element(By.CSS_SELECTOR, "#particularsBedrooms").text.replace("'","")
            
        # Address of Property 
        if is_element_exists(driver, By.CSS_SELECTOR, "#particularsAddress"):
            address = driver.find_element(By.CSS_SELECTOR, "#particularsAddress").text.replace("'","")
        
        # Property value    
        if is_element_exists(driver, By.CSS_SELECTOR, "#particularsPrice"):
            value = driver.find_element(By.CSS_SELECTOR, "#particularsPrice").text.split(" ")
            for val in value:
                if val.startswith("£"):
                    property_value = float(val[1:].replace(",",""))
             
        # Agent Details
        agent_details ={}
        if is_element_exists(driver, By.CSS_SELECTOR, "#branchTelephone"):
            agent_details["agent_num"] = driver.find_element(By.CSS_SELECTOR, "#branchTelephone").text.replace("'","")
        if is_element_exists(driver, By.CSS_SELECTOR, "#branchEmail"):
            agent_details["agent_email"] = driver.find_element(By.CSS_SELECTOR, "#branchEmail").text.replace("'","")
            
        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "img.sp-image"):
            image_urls = driver.find_elements(By.CSS_SELECTOR, "img.sp-image")
            image_urls = [i.get_attribute('src').replace("'","") for i in image_urls]

        # Brochure Link of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "#particularsMenu ul li:last-child a"):
             brochure = driver.find_element(By.CSS_SELECTOR, "#particularsMenu ul li:last-child a").get_attribute('href')
             
        # Description of Property
        if is_element_exists(driver,By.CSS_SELECTOR, '#description ul li'):
            features = driver.find_elements(By.CSS_SELECTOR, "#description ul li")
            features = [i.text.replace("'","") for i in features]
        if is_element_exists(driver,By.CSS_SELECTOR, '#description p'):
            descr = driver.find_elements(By.CSS_SELECTOR, "#description p")
            descr = [i.text.replace("'","") for i in descr]
        description.append({"type": "text", "value": descr})
        description.append({"type": "list", "value": features})
        
    
        
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append("For Sale")
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass
    
driver.close()




