import sys
import json
import datetime
import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://www.sia-group.co.uk/property-type/properties-for-sale/"
driver = get_chrome_driver()
driver.get(base_url)

connection = create_server_connection()
cursor = connection.cursor()

property_urls = []        
while(is_element_exists(driver, By.CSS_SELECTOR, ".page-numbers")):
    property_links = driver.find_elements(
        By.CSS_SELECTOR, ".btn")

    for span in property_links:
        if span.get_attribute("href") not in property_urls:
            property_urls.append(span.get_attribute("href"))
            
    if is_element_exists(driver, By.CSS_SELECTOR, ".prev"):
        property_links = driver.find_elements(By.CSS_SELECTOR, ".btn")

        for span in property_links:
            if span.get_attribute("href") not in property_urls:
                property_urls.append(span.get_attribute("href"))
        break

    driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, ".next"))))
    

for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url+"#main-content")
        driver.implicitly_wait(8)
        #if is_element_exists(driver, )

        name = type_of_property = address = brochure = rent_unit = type_property = ""
        rent = property_value = latitude = longitude = 0
        description = []
        agent_details = {}
        image_urls = []
        
        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, '.property-text-content h3'):
            name = driver.find_element(By.CSS_SELECTOR, '.property-text-content h3').text.replace("'","")
        
        #Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-location-address"):
            address = driver.find_element(By.CSS_SELECTOR, ".property-location-address").text.replace("'","")

        # Type of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-value:nth-of-type(2)"):
            type_property = driver.find_element(By.CSS_SELECTOR, ".property-value:nth-of-type(2)").text.replace("'","")
            
        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-text-content p"):
            description = driver.find_elements(By.CSS_SELECTOR, ".property-text-content p")
            description = [i.text.replace("'","").replace("\n"," ") for i in description]
        
        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".fotorama img"):
            image_urls = driver.find_elements(By.CSS_SELECTOR, ".fotorama img")
            image_urls = [i.get_attribute('src') for i in image_urls]
            
        # Agent Details of Property
        if is_element_exists(driver,  By.CSS_SELECTOR, ".property-agent-name"):
            agent_details["agent_name"] =  driver.find_element(
                By.CSS_SELECTOR, ".property-agent-name").text.replace("'","")
                
        if is_element_exists(driver,  By.CSS_SELECTOR, ".property-agent-phone"):
            agent_details["agent_phone"] = driver.find_element(
                By.CSS_SELECTOR, ".property-agent-phone").text.replace("'","")
                    
        if is_element_exists(driver,  By.CSS_SELECTOR, ".property-agent-email"):
            agent_details["agent_email"] = driver.find_element(
                By.CSS_SELECTOR, ".property-agent-email").text.replace("'","")
                    
        if is_element_exists(driver,  By.CSS_SELECTOR, ".property-element-agent img"):
            agent_details["agent_image"] =  driver.find_element(
                By.CSS_SELECTOR, ".property-element-agent img").get_attribute('src')


        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))
        
        
        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print(type(e).__name__, __file__, e, e.__traceback__.tb_lineno)
        f = open("error.log", "a")
        f.write(f"Filename: {sys.argv[0]} \n")
        f.write(f"Error in link: {url} \n")
        f.write(f"Time:- {datetime.datetime.now()} \n")
        f.write(str(traceback.format_exc()))
        f.write("\n")
        f.close()
        pass

driver.close()