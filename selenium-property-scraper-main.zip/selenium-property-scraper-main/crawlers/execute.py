import os

crawlers = ['agg_scrapper.py', 'bk_scrapper.py', 'bnp_scrapper.py', 
            'cc_scrapper.py','ch_scrapper.py', 'dnb_scrapper.py',
            'fb_scrapper.py', 'fjl_scrapper.py', 'fkp_scrapper.py', 
            'ine_scrapper.py', 'lwg_scrapper.py', 'mg_scrapper.py',
            'mp_scrapper.py','sfp_scrapper.py', 'sia_scrapper.py',
            'wdb_scrapper.py', 'ws_scrapper.py'  
]
for crawler in crawlers:
    exec(open(crawler).read())