import sys
import json
import datetime
import traceback
from selenium.webdriver.common.by import By
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection


base_url = "https://www.realestate.bnpparibas.co.uk/property/search?trans_type=for_rent&location=&location_coords=0"
connection = create_server_connection()
cursor = connection.cursor()
driver = get_chrome_driver()
driver.get(base_url)

property_links = driver.find_elements(By.CSS_SELECTOR, ".col-results a")
property_urls = []

for span in property_links:
    if span.get_attribute("href") not in property_urls:
        property_urls.append(span.get_attribute("href"))


for link in property_urls:

    try:
        print("Link: ", link)
        driver.get(link)

        name = type_property = address = brochure = block_quote = paragraph = rent_unit = ""
        rent = property_value = latitude = longitude = 0

        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-title .title"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".block-title .title").text
            name = name.replace("'", '')

        # Type of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-title .label"):
            type_property = driver.find_element(
                By.CSS_SELECTOR, ".block-title .label").text

        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-title .position span, .block-title .phone span"):
            address = driver.find_element(
                By.CSS_SELECTOR, ".block-title .position span, .block-title .phone span").text
            address = address.replace("'", '')

        # Brochure link of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-property-description .sidebar .brochure-link"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, ".block-property-description .sidebar .brochure-link").get_attribute("href")

        # Location of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-property-location .btn"):
            location = driver.find_element(
                By.CSS_SELECTOR, ".block-property-location .btn").get_attribute("href")

        # Images of Property
        image_urls = []
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-slider .owl-carousel .item img"):
            for image in driver.find_elements(By.CSS_SELECTOR, ".block-slider .owl-carousel .item img"):
                image_urls.append(image.get_attribute('src'))

        # Agent details of Property
        agent_list = []
        if is_element_exists(driver, By.CSS_SELECTOR, ".btn-block"):
            for i in driver.find_elements(By.CSS_SELECTOR, ".btn-block"):
                agents = i.get_attribute("data-action-payload")

            agent_details = json.loads(agents)['contacts']
            for agent in agent_details:
                agent_list.append(
                    [agent['name'], agent['picture'], agent['phone']['phone_number'], agent['email']])

        # Description of Property
        description = []
        if is_element_exists(driver, By.CSS_SELECTOR, ".component-wysiwyg blockquote"):
            block_quote = "".join(driver.find_element(
                By.CSS_SELECTOR, ".component-wysiwyg blockquote").text.split('\n'))
            block_quote = block_quote.replace("'", '')

        if is_element_exists(driver, By.CSS_SELECTOR, ".component-wysiwyg p"):
            paragraph = "".join(driver.find_element(
                By.CSS_SELECTOR, ".component-wysiwyg p").text.split('\n'))
            paragraph = paragraph.replace("'", '')

        if is_element_exists(driver, By.CSS_SELECTOR, ".items .item"):
            property_features = driver.find_elements(
                By.CSS_SELECTOR, ".items .item")
            property_features_list = []
            for feature in property_features:
                property_features_list.append(feature.text.replace("'", ''))

        description.append({"type": "text", "value": block_quote})
        description.append({"type": "text", "value": paragraph})
        description.append({"type": "list", "value": property_features_list})

        # Features of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".col-12 .features .feature"):
            features_dict = {}
            features_list = []
            for feat in driver.find_elements(By.CSS_SELECTOR, ".col-12 .features .feature"):
                features_list.append(feat.text.split('\n'))
            for ft in features_list:
                features_dict[ft[0]] = ft[1]

            if "RENT /sq ft" in features_dict.keys():
                rent_unit = "RENT /sq ft"
                rent = float(features_dict[rent_unit][1:])
            if "RENT" in features_dict.keys():
                rent_unit = "RENT"
                rent = float(features_dict[rent_unit][1:].replace(",", ""))

        payload = []
        payload.append(link)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_list))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append("FOR RENT")
        payload.append(0)
        payload.append(float(location.split("/")[5].split(",")[0]))
        payload.append(float(location.split("/")[5].split(",")[1]))
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
    except Exception as e:
        print(type(e).__name__, __file__, e, e.__traceback__.tb_lineno)
        f = open("error.log", "a")
        f.write(f"Filename: {sys.argv[0]} \n")
        f.write(f"Error in link: {link} \n")
        f.write(f"Time:- {datetime.datetime.now()} \n")
        f.write(str(traceback.format_exc()))
        f.write("\n")
        f.close()
        pass


driver.close()
