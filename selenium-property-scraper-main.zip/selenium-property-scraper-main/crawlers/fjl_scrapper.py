import sys
import json
import datetime
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.connection import create_server_connection
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver


base_url = "https://search.fljltd.co.uk/properties?paging=viewall"
connection = create_server_connection()
cursor = connection.cursor()
driver = get_chrome_driver()
driver.get(base_url)


property_links = driver.find_elements(By.CSS_SELECTOR, ".propText h3 a")
property_urls = []
for span in property_links:
    property_urls.append(span.get_attribute("href"))

for url in property_urls:

    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = block_quote = paragraph = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        description = agent_details = image_urls = []

        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-title .title"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".propTitle h1").text
            name = name.replace("'","")


        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".block-title .position span, .block-title .phone span"):
            address = " ".join(driver.find_element(
                By.CSS_SELECTOR, ".propTitle").text.split('\n'))
            address = address.replace("'","")


        # Property Features (Rent, Property Value, Rent unit, tenure)
        if is_element_exists(driver, By.CSS_SELECTOR, ".propertypage .post table"):
            table = driver.find_element(
                By.CSS_SELECTOR, ".propertypage .post table").text.split('\n')
            for entry in table:
                if entry.startswith("Tenure"):
                    type_of_property = " ".join(entry.split(" ")[1:])
                if entry.startswith("Property Type"):
                    property_type = entry.split(" ")[2]
                if entry.startswith("Rent"):
                    value = entry.split(" ")
                    if "per" and "desk" in value:
                        rent_unit = "Per Desk From"
                        rent = float([i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                    if "per" and "sq" and "ft" in value:
                        rent_unit = "Per Sq Ft"
                        rent = float([i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                    if "per" and "annum" in value:
                        rent_unit = "Per Annum"
                        rent = float([i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                    if "per" and "month" in value:
                        rent_unit = "Per Month"
                        rent = float([i.replace(",", "") for i in value if i.startswith("£")][0][1:])
                if entry.startswith("Price"):
                    price_list = entry.split(" ")
                    property_value = float([i.replace(",", "") for i in price_list if i.startswith("£")][0][1:])

        # Agent Details List
        if is_element_exists(driver, By.CSS_SELECTOR, ".contactUser"):
            agents = driver.find_elements(By.CSS_SELECTOR, ".contactUser")
            for i in agents:
                agent_details.append(i.text.split("\n")[:2])

        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".propertypage .post h2"):
            elements = driver.find_elements(
                By.CSS_SELECTOR, ".propertypage .post h2")
            elements = [i.text for i in elements]
            if "Key Points" in elements:
                key_points = driver.find_elements(
                    By.CSS_SELECTOR, ".propertypage .post ul")
                key_points = [i.text for i in key_points]
                if len(key_points) == 3:
                    key_points = key_points[1].split("\n")
                if len(key_points) == 2:
                    key_points = key_points[1].split("\n")
                if len(key_points) == 1:
                    key_points = key_points[0].split("\n")
            if "Description" in elements:
                text = driver.find_elements(
                    By.CSS_SELECTOR, ".propertypage .post")
                text = [i.text for i in text][0].split('\n')
                paragraph = text[text.index("Description")+1]
            if "Location" in elements:
                text = driver.find_elements(
                    By.CSS_SELECTOR, ".propertypage .post")
                text = [i.text for i in text][0].split('\n')
                location = text[text.index("Location")+1]
            description.append({"type": "text", "value": paragraph.replace("'","")})
            description.append({"type": "text", "value": location.replace("'","")})
            description.append({"type": "list", "value": [i.replace("'","") for i in key_points]})

        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".row .cycle-slideshow-thumbnails div img"):
            for image_url in driver.find_elements(By.CSS_SELECTOR, ".row .cycle-slideshow-thumbnails div img"):
                image_urls.append(image_url.get_attribute('src'))

        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(0)
        payload.append(0)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ",e)
        exc = traceback.format_exc()
        exception(url,exc)
        pass


driver.close()
