import re
import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_urls = ["https://cityandcounties.com/buy/property-for-sale",
             "https://cityandcounties.com/let/property-to-let"]

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()


property_urls = []
for link in base_urls:
    driver.get(link)
    driver.implicitly_wait(8)

    pages = driver.find_elements(
        By.CSS_SELECTOR, '.pagination-wrapper:nth-of-type(1) .pagination li a')
    pages = set([page.get_attribute('data-page') for page in pages])

    page_count = 1
    for page in pages:
        driver.get(f"{link}?page={page_count}")
        driver.implicitly_wait(8)
        page_count += 1

        property_links = driver.find_elements(
            By.CSS_SELECTOR, ".property-description-link")

        for span in property_links:
            if span.get_attribute("href") not in property_urls:
                property_urls.append(span.get_attribute("href"))


for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        description = []
        image_urls = []
        agent_details = ""

        # Name of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-address span"):
            name = driver.find_element(
                By.CSS_SELECTOR, ".property-address span").text.replace("'", "")

        # Address of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-address"):
            address = " ".join(driver.find_elements(
                By.CSS_SELECTOR, ".property-address")[0].text.split("\n")).replace("'", "")

        # Brochure link of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".main #brochure a"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, ".main #brochure a").get_attribute('href')

        # Features of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".accordion-group:nth-of-type(1) .color-white  li"):
            features_elements = driver.find_elements(
                By.CSS_SELECTOR, ".accordion-group:nth-of-type(1) .color-white  li")
            features = [i.text.replace("'","") for i in features_elements]
            features
            for feature in features:
                if feature.startswith("Price"):
                    value = feature.split('-')[1]
                    if "annum" in value.lower():
                        rent_unit = "Per Annum"
                        rent = value.split(" ")
                        rent = float([i.replace(",", "")
                                     for i in rent if i.startswith("£")][0][1:])
                    if "sqft" in value.lower():
                        rent_unit = "Per SqFt"
                        rent = value.split(" ")
                        rent = float([i.replace(",", "")
                                     for i in rent if i.startswith("£")][0][1:])
                    else:
                        if value.startswith("£"):
                            property_value = float(value.replace(",",""))
                if feature.startswith("Property Type"):
                    type_property = feature.split("-")[1]

        # Description of Property
        if is_element_exists(driver, By.CSS_SELECTOR, "#description p"):
            description_text = " ".join(driver.find_element(
                By.CSS_SELECTOR, "#description p").text.split()).strip().replace("'", "")

        description.append({"type": "text", "value": description_text})
        
        # Agent_Details of Property given in description paragraph
        agent_details = description_text[description_text.index(
            "For more "):].replace("'", "") if "For more" in description_text else ""

        # Images of Property
        if is_element_exists(driver, By.CSS_SELECTOR, ".owl-stage .owl-image img"):
            image_urls = driver.find_elements(
                By.CSS_SELECTOR, ".owl-stage .owl-image img")
            image_urls = [i.get_attribute(
                'src') for i in image_urls if i.get_attribute('src') is not None]        

        # latitude and longitude
        if is_element_exists(driver, By.CSS_SELECTOR, ".property-details .main #maps"):
            lat_long = json.loads(driver.find_element(By.CSS_SELECTOR, ".property-details .main #maps").get_attribute('data-cords'))
            if len(lat_long['lat'])>0 and len(lat_long['lng'])>0:
                latitude = lat_long['lat']
                longitude = lat_long['lng']
            
            
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass
    
driver.close()
