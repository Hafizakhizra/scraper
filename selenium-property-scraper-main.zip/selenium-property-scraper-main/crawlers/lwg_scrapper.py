import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

base_url = "http://landwoodcorp.wpengine.com/properties-available/"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(8)

property_urls = []
for span in driver.find_elements(By.CSS_SELECTOR, '.vert-center a:nth-of-type(2)'):
    property_urls.append(span.get_attribute("href"))
    
for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)
        
        name = type_property = address = brochure = description = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        agent_details= {} 
        image_urls = []
        
        # Name of Property
        if is_element_exists(driver,By.CSS_SELECTOR,".wpb_wrapper .vc_custom_heading"):
            name = driver.find_element(By.CSS_SELECTOR,".wpb_wrapper .vc_custom_heading").text.split(',')[0].replace("'","")
            address  = driver.find_element(By.CSS_SELECTOR,".wpb_wrapper .vc_custom_heading").text.replace("'","")
        
        # Agent_details of property
        if is_element_exists(driver,By.CSS_SELECTOR, ".nectar-cta h5 .link_wrap a"):
            agent_details_elements = driver.find_elements(By.CSS_SELECTOR, ".nectar-cta h5 .link_wrap a")[2:]
            agent_details = [i.text.replace("'","") for i in agent_details_elements]
        
        # Description of Property
        if is_element_exists(driver,By.CSS_SELECTOR, ".wpb_wrapper ul "):
            description = driver.find_element(By.CSS_SELECTOR,".wpb_wrapper ul ").text.split('\n')
            description = [i.replace("'","") for i in description]
        
        # Images of Property
        if is_element_exists(driver,By.CSS_SELECTOR, ".swiper-slide a"):
            image_elements = driver.find_elements(By.CSS_SELECTOR,".swiper-slide a")
            image_urls = [i.get_attribute('href') for i in image_elements]
        
        # Features of Property
        features_values_elements = driver.find_elements(By.CSS_SELECTOR,".wpb_wrapper .nectar-fancy-ul")
        features_values = [i.text for i in features_values_elements]

        features_name_elements = driver.find_elements(By.CSS_SELECTOR,".wpb_content_element .wpb_wrapper h5")
        features_names = [i.text for i in features_name_elements]

        features = dict(zip(features_names, features_values))
        if "Type" in features.keys():
            type_property = features["Type"]
        if "Status" in features.keys():
            type_of_property = features["Status"]
        if "Price" in features.keys():
            value = features['Price']
            if len(value)>0:
                value = [i.lower() for i in value.split(" ")]
                if "sq" and "ft" in value:
                    rent_unit = "Per sq ft"
                    rent = float(
                        [i.replace(",","") for i in value if i.startswith("£")][0][1:])
                if "pcm" in value:
                    rent_unit = "PCM"
                    rent = float(
                        [i.replace(",","") for i in value if i.startswith("£")][0][1:])
                if "per" and "annum" in value:
                    rent_unit = "Per Annum"
                    rent = float(
                        [i.replace(",","") for i in value if i.startswith("£")][0][1:])
                else:
                    for price in value:
                        if price.startswith("£"):
                            property_value = float(price[1:].replace(",",""))
          
        # Brochure_link of Property  
        if is_element_exists(driver,By.CSS_SELECTOR, ".nectar-cta h5 .link_wrap a"):
            brochure = driver.find_elements(By.CSS_SELECTOR,".nectar-cta h5 .link_wrap a")[1].get_attribute("href")

            
            
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(0)
        payload.append(0)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print("Error: ",e)
        exc = traceback.format_exc()
        exception(url,exc)
        pass


driver.close()