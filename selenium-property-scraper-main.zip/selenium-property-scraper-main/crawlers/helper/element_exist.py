from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.common.exceptions import NoSuchElementException


def is_element_exists(driver, by, element):
    try:
        driver.find_element(
            by, element)
        return True
    except:
        return False
