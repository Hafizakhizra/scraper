import psycopg2


def create_server_connection():
    connection = None
    connection = psycopg2.connect(
        user='postgres',
        password="2019",
        database="property-pool",
        host="localhost",
        port=5433,
    )
    return connection


def execute_query(connection, query):
    cursor = connection.cursor()
    cursor.execute(query)
    connection.commit()
    print("Query successful")
