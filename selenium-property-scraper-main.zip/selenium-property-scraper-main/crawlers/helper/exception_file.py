import sys
import datetime


def exception(link,exc):
    f = open("Error.log", "a")
    f.write(f"Filename: {sys.argv[0]} \n")
    f.write(f"Error in link: {link} \n")
    f.write(f"Time:- {datetime.datetime.now()} \n")
    f.write(str(exc))
    f.write("\n")
    f.close()