import json
import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection

base_url = 'https://www.fletcherbond.co.uk/properties/'
connection = create_server_connection()
cursor = connection.cursor()
driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(8)

properties_details = []
for i in driver.find_elements(By.CSS_SELECTOR, ".et_pb_section_1 .et_pb_column"):
    properties_details.append(i.text)
properties_details = properties_details[:len(properties_details)-1]


names_elements = driver.find_elements(By.CSS_SELECTOR,".et_pb_module_header")
names = [i.text for i in names_elements]


address_elements = driver.find_elements(By.CSS_SELECTOR,".et_pb_module_header")
address = [i.text for i in names_elements]


description_elements = driver.find_elements(By.CSS_SELECTOR,".et_pb_blurb_description ul")
description = [i.text.split('\n') for i in description_elements]
    
    
type_of_property_elements =driver.find_elements(By.CSS_SELECTOR,".et_pb_blurb_description span strong")
type_of_property = []
for i in type_of_property_elements:
    type_of_property.append(i.text)

    
images_elements = driver.find_elements(By.CSS_SELECTOR,'.et_pb_section_1 .et_pb_row .et_pb_main_blurb_image span img')
images = [i.get_attribute('src') for i in images_elements]

    
brochure_elements = driver.find_elements(By.CSS_SELECTOR,".et_pb_section .et_pb_button")
brochure_list = [i.get_attribute('href') for i in brochure_elements]
brochure_count = 0

property_count = 1
for i in range(len(properties_details)):
    try:
        print("Link: ", base_url)
        payload = []
        payload.append(base_url+f"?property={property_count}")
        property_count+=1
        payload.append(names[i])
        payload.append(address[i])
        payload.append(json.dumps(""))
        payload.append(json.dumps(description[i]))
        payload.append(json.dumps(images[i]))
        payload.append(0)
        payload.append(0)
        payload.append(type_of_property[i])
        payload.append(0)
        payload.append(0)
        payload.append(0)
        if "PROPERTY DETAILS" in properties_details[i]:
            brochure = brochure_list[brochure_count]
            brochure_count+=1
        else:
            brochure = ""
        payload.append(brochure.replace("'",""))
        payload.append("")
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name='{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
        
    except Exception as e:
        print("Error: ",e)
        exc = traceback.format_exc()
        exception(base_url,exc)
        pass


driver.close()