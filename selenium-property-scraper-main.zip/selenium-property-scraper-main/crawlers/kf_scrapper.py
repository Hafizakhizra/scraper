import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


base_url = "https://www.clarkeholland.com/site/go/search?sales=true&min=0&includeUnavailable=true&beds=0&items=12&type=0&max=0&location=&search=&page=1&up=false&sort=onmarket"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()


base_urls = ["https://www.knightfrank.com/properties/commercial/for-sale/uk-greater-london-london/all-types/all-floor",
            "https://www.knightfrank.com/properties/commercial/to-let/uk-greater-london-london/all-types/all-floor"]

property_urls = []
for url in base_urls:
    driver.get(url) 
    driver.implicitly_wait(10)

    
    while driver.find_element(By.CSS_SELECTOR,".inner-wrapper a"):
        #time.sleep(5)
        #driver.implicitly_wait(10)
        property_links = driver.find_elements(By.XPATH,'//*[@id="main"]/div/section[1]/div/div/div/property/div/div/div/a') 

        for span in property_links: 
            if span.get_attribute("href") not in property_urls and span.get_attribute("href") is not None: 
                property_urls.append(span.get_attribute("href")) 
        try:
            driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "/html/body/section/kf-search/ng-component/div[2]/div/div[2]/div/section[2]/div/div/pager-small/ul/li[7]/a/i")))) 
        except:
            break


for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)
        driver.implicitly_wait(10)

        name = type_property = address = brochure = rent_unit = descr = read_more = ""
        rent = property_value = latitude = longitude = 0
        description = []
        image_urls = []
        agent_details = ""
        
        
        # name and address
        if is_element_exists(driver, By.CSS_SELECTOR, 'property-title h1'):
            name = driver.find_element(By.CSS_SELECTOR, "property-address-title").text.split(',')[0]
            address = driver.find_element(By.CSS_SELECTOR, "property-address-title").text.replace("\n",", ")
         
         
        # Features of Proeprty price valu etc    
        if "for-sale" in url:
            type_of_property = "FOR SALE"
            if is_element_exists(driver, By.CSS_SELECTOR, ".price"):
                value = driver.find_element(By.CSS_SELECTOR, ".price").text.split(" ")
                for val in value:
                    if val.startswith("£"):
                        property_value = float(val[1:].replace(",",""))
        if "to-let" in url:
            type_of_property = "TO LET"
            if is_element_exists(driver, By.CSS_SELECTOR, ".price"):
                value = driver.find_element(By.CSS_SELECTOR, ".price").text.split(" ")
                for val in value:
                    if val.startswith("£"):
                        rent = float(val[1:].replace(",",""))
                    if "sq" and "ft" in value:
                        rent_unit = "Per Sq Ft"
                    if "pa" in value:
                        rent_unit = "Per Annum"
          
        # Description
        if is_element_exists(driver,By.CSS_SELECTOR, '.short-description'):
            descr = driver.find_element(By.CSS_SELECTOR, '.short-description').text.replace("'","")
        if is_element_exists(driver, By.CSS_SELECTOR, '.read-more p'):
            read_more = driver.find_element(By.CSS_SELECTOR, ".read-more p").text.replace("'","").replace("\n"," ")
            
        description.append({"type": "text", "value": descr})
        description.append({"type": "text", "value": read_more})              
        
        # Images 
        if is_element_exists(driver, By.CSS_SELECTOR ,".col-sm-9 img"):
            image_urls = driver.find_elements(By.CSS_SELECTOR, ".col-sm-9 img")
            image_urls = [i.get_attribute('src') for i in image_urls]
            
        # Brochure
        if is_element_exists(driver, By.CSS_SELECTOR, "property-details-sold .pdp-additional-links-wrapper .pdp-additional-links .element-wrapper .element>a, property-details .pdp-additional-links-wrapper .pdp-additional-links .element-wrapper .element>a"):
            brochure = driver.find_element(
                By.CSS_SELECTOR, "property-details-sold .pdp-additional-links-wrapper .pdp-additional-links .element-wrapper .element>a, property-details .pdp-additional-links-wrapper .pdp-additional-links .element-wrapper .element>a"
            ).get_attribute('href')
            
        # Agent_details
        agent_details = {}
        driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((
                By.CSS_SELECTOR, "agents-card-list ul li button")))) 
        agent_details[f"agent_name"] = driver.find_element(By.CSS_SELECTOR, ".contact-name").text
        agent_details[f"agent_phone"] = driver.find_element(By.CSS_SELECTOR, ".contact-phone a").get_attribute('href')
    
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append("For Sale")
        payload.append(property_value)
        payload.append(latitude)
        payload.append(longitude)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()

    except Exception as e:
        print("Error: ", e)
        exc = traceback.format_exc()
        exception(url, exc)
        pass
    
driver.close()
