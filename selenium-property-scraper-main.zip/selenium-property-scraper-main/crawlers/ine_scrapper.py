import json
import traceback
from selenium import webdriver
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.driver_config import get_chrome_driver
from helper.element_exist import is_element_exists
from helper.connection import create_server_connection
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
    
base_url = "https://www.innes-england.com/property-search/results/search&radius_unit=mi&unit=ft&limit=9"

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)
driver.implicitly_wait(8)


property_urls = []
try:
    while(driver.find_element(By.CSS_SELECTOR, ".pagination li .page-next")):

        property_links = driver.find_elements(By.CSS_SELECTOR, ".panel-property a")

        for span in property_links:
            if span.get_attribute("href") not in property_urls:
                property_urls.append(span.get_attribute("href"))

        driver.execute_script("arguments[0].click();", WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, ".pagination li .page-next"))))
except:
    pass
    

for url in property_urls:
    try:
        print("Link: ", url)
        driver.get(url)

        name = type_property = address = brochure = description = rent_unit = type_of_property = ""
        rent = property_value = latitude = longitude = 0
        agent_details= {} 
        image_urls = []
        
        
        # Name of Property
        if is_element_exists(driver,By.CSS_SELECTOR,"article .mb60 h1"):
            name = driver.find_element(By.CSS_SELECTOR,"article .mb60 h1").text
            name = name.replace("'","")
        
        
        # Address of Property
        if is_element_exists(driver,By.CSS_SELECTOR, ".panel-subtle .mb0"):
            address = " ".join(driver.find_element(By.CSS_SELECTOR, ".panel-subtle .mb0").text.split("\n"))
            address = address.replace("'","")
        
        
        # Agent Details of Property
        if is_element_exists(driver,By.CSS_SELECTOR,".panel.contact-the-agent h3"):
            agent_details['agent_name'] = driver.find_element(
                By.CSS_SELECTOR,".panel.contact-the-agent h3").text.replace("'","")
            
        if is_element_exists(driver,By.CSS_SELECTOR,".panel.contact-the-agent .tel a"):
            agent_details['agent_phone'] = driver.find_element(
                By.CSS_SELECTOR,".panel.contact-the-agent .tel a").text
            
        if is_element_exists(driver,By.CSS_SELECTOR,".panel.contact-the-agent .location"):
            agent_details['agent_location'] = driver.find_element(
                By.CSS_SELECTOR, ".panel.contact-the-agent .location").text.replace("'","")
            
        if is_element_exists(driver,By.CSS_SELECTOR,".panel.contact-the-agent a img"):
            agent_details["agent_image"] = driver.find_element(
                By.CSS_SELECTOR, ".panel.contact-the-agent a img").get_attribute('src')
            
        if is_element_exists(driver,By.CSS_SELECTOR,".panel.contact-the-agent .email span a"):
            agent_details['agent_mail'] = driver.find_element(
                By.CSS_SELECTOR,'.panel.contact-the-agent .email span a').get_attribute('href')
        
        
        # Description of Property
        if is_element_exists(driver,By.XPATH,'/html/body/div[2]/div[2]/main/div[1]/div/article/div/p'):
            description = driver.find_element(By.XPATH,'/html/body/div[2]/div[2]/main/div[1]/div/article/div/p').text
            description = description.replace("'","")


        # Rent, Rent unit and Property Value
        value =  driver.find_elements(By.CSS_SELECTOR, ".panel-subtle .mb0")[1].text
        if len(value)>0:
            value = value.lower().split(" ")

            if "sq" and "ft" in value:
                rent_unit = "Per sq ft"
                rent = float([i.replace(",","") for i in value if i.startswith("£")][0][1:])
            if "pcm" in value:
                rent_unit = "PCM"
                rent = float([i.replace(",","") for i in value if i.startswith("£")][0][1:])
            if "per" and "annum" in value:
                rent_unit = "Per Annum"
                rent = float([i.replace(",","") for i in value if i.startswith("£")][0][1:])
            if "per" and "month" in value:
                rent_unit = "Per Month"
                rent = float([i.replace(",","") for i in value if i.startswith("£")][0][1:])
            else:
                for price in value:
                    if price.startswith("£"):
                        if not price.endswith("m"):
                            property_value = float(price[1:].replace(",",""))
                        else:
                             property_value = float(price[1:2])* 1000000
        
        
        # Images of Property
        if is_element_exists(driver,By.CSS_SELECTOR,".flexslider .slides li .img-responsive"):
            for img in driver.find_elements(By.CSS_SELECTOR,".flexslider .slides li .img-responsive"):
                if img.get_attribute("src") not in image_urls:
                    image_urls.append(img.get_attribute("src"))
        
        
        # Brochure link of Property
        if is_element_exists(driver,By.CSS_SELECTOR,".btn.mt30"):
            brochure = driver.find_element(By.CSS_SELECTOR,".btn.mt30").get_attribute('href')
            
        payload = []
        payload.append(url)
        payload.append(name)
        payload.append(address)
        payload.append(json.dumps(agent_details))
        payload.append(json.dumps(description))
        payload.append(json.dumps(image_urls))
        payload.append(rent)
        payload.append(rent_unit)
        payload.append(type_of_property)
        payload.append(property_value)
        payload.append(0)
        payload.append(0)
        payload.append(brochure)
        payload.append(type_property)
        payload.append(json.dumps({}))

        query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

        cursor.execute(query)
        connection.commit()
        
    except Exception as e:
        print("Error: ",e)
        exc = traceback.format_exc()
        exception(url,exc)
        pass


driver.close()

        

