CREATE TABLE properties(
	id serial PRIMARY KEY,
	source varchar(2000) UNIQUE,
	name varchar(2000),
	address varchar(2000),
	agent_details json[],
	description json,
	images json,
	rent float,
    unit varchar(2000),
    type varchar(2000),
	property_value float,
	latitude float,
	longitude float,
	brochure_link varchar(2000),
	property_type varchar(2000),
	tags json
);