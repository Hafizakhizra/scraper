import json
import traceback
from selenium.webdriver.common.by import By
from helper.exception_file import exception
from helper.element_exist import is_element_exists
from helper.driver_config import get_chrome_driver
from helper.connection import create_server_connection

base_url = 'https://www.whitedrucebrown.com/available-properties/'

connection = create_server_connection()
cursor = connection.cursor()

driver = get_chrome_driver()
driver.get(base_url)

try:
    print("Link: ", base_url)

    name = type_property = address = brochure = rent_unit = type_of_property = ""
    rent = property_value = latitude = longitude = 0
    description = []
    image_urls = []
    agent_details = ""
    
    if is_element_exists(driver, By.CSS_SELECTOR, '.pdf-block a'):
        brochure_links = driver.find_elements(By.CSS_SELECTOR, ".pdf-block a")
        brochure_links = [i.get_attribute('href') for i in brochure_links]


    if is_element_exists(driver,By.CSS_SELECTOR, ".col-12.col-md-3"):
        property_containers = driver.find_elements(By.CSS_SELECTOR, ".col-12.col-md-3")
        property_containers = [i.text for i in property_containers]
        
        brochure_num = 1
        for ppt in property_containers:
            ppt = ppt.split("\n")

            type_property = ppt[0]

            name = ppt[1]

            address = ppt[2]

            value = ppt[3].split("\n")
            value = [i.lower() for i in value]
            for i in value:
                if i.startswith("£"):
                    rent = float(i.replace(",",""))
                    if rent.endswith("pax"):
                        rent_unit = "PAX"
            if "pax" in value:
                rent_unit = "PAX"
            if "sq" and "ft" in value:
                rent_unit = "Per Sq Ft"
            if "psf" in value:
                rent_unit = "PSF"

            type_of_proeprty = ppt[4]
            
            brochure = brochure_links[brochure_num-1]
        
            payload = []
            payload.append(base_url)
            payload.append(name)
            payload.append(address)
            payload.append(json.dumps(agent_details))
            payload.append(json.dumps(description))
            payload.append(json.dumps(image_urls))
            payload.append(rent)
            payload.append(rent_unit)
            payload.append(type_of_property)
            payload.append(property_value)
            payload.append(latitude)
            payload.append(longitude)
            payload.append(brochure)
            payload.append(type_property)
            payload.append(json.dumps({}))
            print(payload)
            query = """INSERT INTO properties (source, name, address, agent_details, description, images, rent, unit, type, property_value, latitude, longitude, brochure_link, property_type, tags) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}','{14}')
                    ON CONFLICT (source) DO UPDATE SET name = '{1}', address = '{2}', agent_details = '{3}', description = '{4}', images = '{5}', rent = '{6}', unit = '{7}', type = '{8}', property_value = '{9}', latitude = '{10}', longitude = '{11}', brochure_link = '{12}', property_type = '{13}', tags = '{14}' """.format(*payload)

            cursor.execute(query)
            connection.commit()

except Exception as e:
    print("Error: ", e)
    exc = traceback.format_exc()
    exception(base_url, exc)
    pass
    
driver.close()
    
